package ru.job4j.firstprog;

/**
 * 14. Вывод на консоль надписи "H-e-l-l-o-,-f-r-i-e-n-d!"
 * Напишите класс, который выводит на экран надпись
 * <p>
 * H-e-l-l-o-,-f-r-i-e-n-d!
 * без перевода на новую строку.
 */
public class Task14 {
    public static void main(String[] args) {
        System.out.print("H-e-l-l-o-,-f-r-i-e-n-d!");
    }
}
