package ru.job4j.exam.collections.generics.book;

public class MyClass {
    public void doSomething() {
        System.out.println("Doing something!");
    }
}

