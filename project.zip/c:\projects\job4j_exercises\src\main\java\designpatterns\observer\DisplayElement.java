package designpatterns.observer;
// этот интерфейс для оторажения визуального элемента
public interface DisplayElement {
    public void display();
}
