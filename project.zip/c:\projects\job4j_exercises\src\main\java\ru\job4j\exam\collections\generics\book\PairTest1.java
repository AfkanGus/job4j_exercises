package ru.job4j.exam.collections.generics.book;

public class PairTest1 {
    public static void main(String[] args) {
        String[] words = {"Mary", "had", "a",
                "little", "lamb"};
        System.out.println();
    }
}
