package type;

/**
 * 4. Целочисленное деление
 */
public class DivMod {
    public static void main(String[] args) {
        int num = 11;
        int div = 3;
        int mod = 11 % 3;
        System.out.println(div);
        System.out.println(mod);
    }
}
