package ru.job4j.firstprog;

/**
 * 4. Не закрытый метод
 * В методе main  забыли закрывающую скобку. Поправь код
 * приведенный ниже.
 */
public class HelloWorld4 {
    public static void main(String[] args) {
        System.out.println("Hello, Job4j!");
    }
}
