package type;

import java.util.Scanner;

/**
 * 1. Объявление переменной.
 */
public class IntType {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int value = in.nextInt();
        System.out.println(value);
    }
}
