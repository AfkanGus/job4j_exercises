package type;

public class MathPow {
    public static void main(String[] args) {
        double rls = Math.pow(3, 2);
        System.out.println(rls);
    }
}
