package ru.job4j.firstprog;

/**
 * 3. Незакрытый класс
 * Ниже приведен код в котором забыли закрыть блок класса.
 * Поправьте ошибку.
 */
public class HelloWorld3 {
    public static void main(String[] args) {
        System.out.println("Hello, Job4j!");
    }
}
