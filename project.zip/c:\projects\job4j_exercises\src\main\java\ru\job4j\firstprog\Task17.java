package ru.job4j.firstprog;

/**
 * 17. Вывод на консоль квадрат и куб числа
 * Напишите класс, который присваивает переменной х значение 6,
 * а затем выводит на экран: в первой строке ― это значение,
 * во второй ― квадрат этого значения, в третьей ― куб этого значения.
 */
public class Task17 {
    public static void main(String[] args) {
        int x = 6;
        System.out.println(x);
        System.out.println(x * x);
        System.out.println(x * x * x);
    }
}
