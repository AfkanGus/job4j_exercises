package ru.job4j.firstprog;

/**
 * 5. Скобки только фигурные.
 * Начинающий Java программист решил заменить фигурные скобки на круглые.
 * Так делать нельзя.
 * Java требует использовать только фигурные скобки для блоков.
 */
public class HelloWorld5 {
    public static void main(String[] args) {
        System.out.println("Hello, Job4j!");
    }
}
