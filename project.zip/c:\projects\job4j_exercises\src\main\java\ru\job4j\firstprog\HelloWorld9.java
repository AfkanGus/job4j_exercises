package ru.job4j.firstprog;

/**
 * 9. Вывод информации на экран
 * System.out.println("Hello, Job4j!");
 * Допишите программу приведенную ниже.
 * Программа должна выводить на консоль строку "Hello, Job4j!"
 */
public class HelloWorld9 {
    public static void main(String[] args) {
        System.out.println("Hello, Job4j!");
    }
}
