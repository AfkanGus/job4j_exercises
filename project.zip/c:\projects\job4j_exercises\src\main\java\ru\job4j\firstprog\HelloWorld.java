package ru.job4j.firstprog;

/**
 * 1. Забытая точка с запятой
 * Каждый оператор в Java должен заканчиваться точкой с запятой.
 * Исправьте ошибку в приведенном коде.
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, Job4j!");
    }
}
