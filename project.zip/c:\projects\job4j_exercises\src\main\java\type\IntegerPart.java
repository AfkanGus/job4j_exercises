package type;

/**
 * 5. Целая часть вещественного числа
 */
public class IntegerPart {
    public static void main(String[] args) {
        float floatNum = 2.6f;
        int integerNUm = (int) floatNum;
        System.out.println(integerNUm);
    }
}
