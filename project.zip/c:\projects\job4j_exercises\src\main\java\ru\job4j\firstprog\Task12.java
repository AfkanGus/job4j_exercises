package ru.job4j.firstprog;

/**
 * 12. Вывод Ping Pong на консоль.
 * Допишите метод main, что программа выводила на консоль две строчки
 * <p>
 * Ping
 * <p>
 * Pong
 * <p>
 * Программа должна печатать каждое слово на новой строке.
 */
public class Task12 {
    public static void main(String[] args) {
        System.out.println("Ping");
        System.out.println("Pong");
    }
}
