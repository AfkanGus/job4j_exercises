package type;

public class MathSqrt {
    public static void main(String[] args) {
        double rsl = Math.sqrt(9);
        double result = Math.abs(-5);
        System.out.println(result);
        System.out.println(rsl);
    }

}
