package ru.job4j.exam.collections.generics;

public class Java {
}
